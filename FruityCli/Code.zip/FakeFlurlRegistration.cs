﻿using Flurl.Http.Configuration;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Controllers;
using Unity;

namespace AcmeSite.Tests.Faking
{
    public static class FakeFlurlRegistration
    {        
        public static Mock<IFlurlClientFactory> UseFakeApis(this IUnityContainer container)
        {
            var fakeFlurlFactory = new Mock<IFlurlClientFactory>();
            container.RegisterInstance<IFlurlClientFactory>(fakeFlurlFactory.Object);
            return fakeFlurlFactory;
        }

        public static void RegisterFakeApi(this Mock<IFlurlClientFactory> fakeFactory, FakeFlurlClient fakeClient)
        {            
            fakeFactory.Setup(x => x.Get(It.Is<Flurl.Url>(url => url.ToString() == fakeClient.BaseUrl))).Returns(fakeClient);
        }        

        public static void RegisterApi(this Mock<IFlurlClientFactory> fakeFactory, string baseUrl, ApiController apiController)
        {
            var fakeFlurlClient = new FakeFlurlClient(baseUrl);
            fakeFactory.RegisterFakeApi(fakeFlurlClient);

            var apiType = apiController.GetType();
            var routePrefix = apiType.Name.Replace("Controller", "");
            var routePrefixAttribute = apiType.GetCustomAttributes(true).OfType<RoutePrefixAttribute>().SingleOrDefault();
            if (routePrefixAttribute != null)
                routePrefix = routePrefixAttribute.Prefix;

            var apiMethods = apiType.GetMethods();
            foreach(var method in apiMethods)
            {
                var routeAttribute = method.GetCustomAttributes(false).OfType<RouteAttribute>().SingleOrDefault();
                if (routeAttribute == null)
                    continue;

                var route = routePrefix + "/" + routeAttribute.Template;
                if (route.EndsWith("/"))
                    route = route.Substring(0, route.Length - 1);
                                    
                var allowedMethods = new List<HttpMethod>();
                foreach(var methodAttibute in method.GetCustomAttributes(false).OfType<IActionHttpMethodProvider>())
                    allowedMethods.AddRange(methodAttibute.HttpMethods);

                if (!allowedMethods.Any())
                    allowedMethods.Add(HttpMethod.Get);

                foreach(var allowedMethod in allowedMethods)
                {
                    var parameters = method.GetParameters().Select(p => Expression.Parameter(p.ParameterType, p.Name));
                    var call = Expression.Call(Expression.Constant(apiController), method, parameters);
                    fakeFlurlClient.SetupRoute(route, allowedMethod, call);
                }
            }
        }
    }
}
