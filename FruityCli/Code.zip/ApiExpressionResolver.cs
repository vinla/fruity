﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;

namespace AcmeSite.Tests.Faking
{
    public class ApiExpressionResolver : ExpressionVisitor
    {
        private readonly string _body;
        private readonly Dictionary<string, string> _wildcards;

        public ApiExpressionResolver(Dictionary<string, string> wildcards, string body)
        {
            _wildcards = wildcards;
            _body = body;
        }

        public object Invoke(Expression expression)
        {
            var mappedExpression = Visit(expression);
            var lambda = Expression.Lambda(mappedExpression);
            var compiled = lambda.Compile();
            return compiled.DynamicInvoke();            
        }

        protected override Expression VisitBinary(BinaryExpression node)
        {
            var mappedLeft = Visit(node.Left);
            var mappedRight = Visit(node.Right);

            return node.Update(mappedLeft, node.Conversion, mappedRight);            
        }

        protected override Expression VisitParameter(ParameterExpression node)
        {
            object argumentValue = null;
            if (_wildcards.ContainsKey(node.Name))
            {
                var wildcardValue = _wildcards[node.Name];
                argumentValue = JsonConvert.DeserializeObject(wildcardValue, node.Type);
            }
            else 
            {
                try
                {
                    argumentValue = JsonConvert.DeserializeObject(_body, node.Type);
                }                
                catch(Exception)
                { }
            }            
            
            return Expression.Constant(argumentValue);
        }

        protected override Expression VisitMemberInit(MemberInitExpression node)
        {
            var mappedBindgings = new List<MemberAssignment>();

            foreach (MemberAssignment binding in node.Bindings.OfType<MemberAssignment>())
                mappedBindgings.Add(binding.Update(Visit(binding.Expression)));            

            return node.Update(node.NewExpression, mappedBindgings);
        }

        protected override Expression VisitInvocation(InvocationExpression node)
        {
            var mappedArguments = new List<Expression>();
            foreach (var argument in node.Arguments)
            {
                mappedArguments.Add(Visit(argument));
            }
            return node.Update(node.Expression, mappedArguments);
        }

        protected override Expression VisitMethodCall(MethodCallExpression node)
        {
            var mappedArguments = new List<Expression>();
            foreach (var argument in node.Arguments)
            {
                mappedArguments.Add(Visit(argument));
            }
            return node.Update(node.Object, mappedArguments);            
        }
    }
}
