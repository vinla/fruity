﻿using AcmeSite.Controllers;
using AcmeSite.BusinessLogic;
using AcmeSite.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Moq;
using AcmeSite.Tests.Faking;
using Flurl.Http;
using Flurl.Http.Configuration;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Unity;
using System.Web.Mvc;
using System.Net.Http;
using Acme.PersonService.Controllers;
using Acme.PersonService.Models;

namespace AcmeSite.Tests.Controllers
{
    [TestClass]
    public class CurrencyControllerTests
    {
        [TestMethod]
        public async Task Test2()
        {
            var actualApi = new PersonController();

            var container = new UnityContainer();
            container.UseAcmeSite();
            var fakeApiFactory = container.UseFakeApis();
            var fakeApi = new FakeFlurlClient(SiteConfig.PersonApi);

            Func<int, Person> createPerson = (personId) => 
            {
                return new Person
                {
                    FirstName = "James",
                    Surname = "Bond",
                    PersonId = personId,
                    DateOfBirth = new DateTime(2000, 1, 1)
                };
            };

            fakeApi.SetupRoute("api/person/{personId}", HttpMethod.Get, (int personId) => createPerson(personId));

            fakeApiFactory.RegisterFakeApi(fakeApi);            

            var peopleController = container.Resolve<PeopleController>();
            var result = await peopleController.PersonDetails(1);

            if (result is ViewResult viewResult)
            {
                if (viewResult.Model is Person person)
                {
                    Assert.AreEqual("James", person.FirstName);
                    Assert.AreEqual("Bond", person.Surname);
                    Assert.AreEqual(1, person.PersonId);
                }
            }
        }

       [TestMethod]
        public async Task Test()
        {
            var actualApi = new PersonController();

            var container = new UnityContainer();
            container.UseAcmeSite();
            var fakeApiFactory = container.UseFakeApis();
            var fakeApi = new FakeFlurlClient(SiteConfig.PersonApi);
            fakeApi.SetupRoute("api/person", HttpMethod.Get, () => actualApi.Get() );
            fakeApi.SetupRoute("api/person", HttpMethod.Post, (Person p) => actualApi.Post(p));           

            fakeApiFactory.RegisterFakeApi(fakeApi);            

            var person = new Person
            {
                FirstName = "Vincent",
                Surname = "Crowe",
                DateOfBirth = new DateTime(1977, 1, 24)
            };

            var peopleController = container.Resolve<PeopleController>();
            var result = await peopleController.AddPerson(person);

            if (result is ViewResult viewResult)
            {
                if(viewResult.Model is Person[] people)
                {
                    Assert.AreEqual("Vincent", people[0].FirstName);
                    Assert.AreEqual("Crowe", people[0].Surname);
                }
            }
        }
    }    
}
