var cardServiceFactory = {
    methods : {
        cardService : function($http) {
            return {
                $http: $http,
                getData: function() {
                    return this.$http.get('/Index?handler=Data');
                }
            }
        }
    }
};
var deckServiceFactory = {
    methods : {
        deckService : function($http) {
            return {
                $http: $http,
                createDeck: function(name) {
                    return this.$http.post('/Index?handler=Create', {name: name});
                }
            }
        }
    }
};