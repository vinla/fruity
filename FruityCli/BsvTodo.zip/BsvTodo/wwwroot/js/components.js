Vue.component('modal-prompt', 
{
  props: ['title', 'message', 'placeholder'],
  data : function ()  {
    return {
      value: ''
    }
  },
  methods: {
    confirm : function(){
      this.$emit('confirm', this.value);
      this.value = ''
    }    
  },
  template: `<div class="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">{{title}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>{{message}}</p>
        <input type="text" class="form-control" v-bind:placeholder="placeholder" v-model="value"/>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" v-on:click="confirm" data-dismiss="modal">Save changes</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>`
})