Vue.component('modal-prompt', 
{
  props: ['title', 'message', 'placeholder'],
  data : function ()  {
    return {
      value: ''
    }
  },
  methods: {
    confirm : function(){
      this.$emit('confirm', this.value);
      this.value = ''
    }    
  },
  template: `<div class="modal" tabindex="-1" role="dialog">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">{{title}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <p>{{message}}</p>
        <input type="text" class="form-control" v-bind:placeholder="placeholder" v-model="value"/>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-primary" v-on:click="confirm" data-dismiss="modal">Save changes</button>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>`
})
Vue.component('data-form', 
{
  props: ['elements'],
  data : function ()  {
    return {
      model: {}
    }
  },
  methods: {
    componentFor : function(type){
      return "data-form-"+type;
    },
    updateModel: function(dataElement, value) {
        alert(dataElement);
        alert(value);
        this.model[dataElement] = value;
        alert(JSON.stringify(this.model));
    }
  },
  template: `<div class="form">
    <div class="form-group" v-for="element in elements">
        <component v-bind:is="componentFor(element.type)" v-bind:data="element" v-on:updated="updateModel(element['data-id'], $event)"></component>
    </div>
    <div>{{model}}</div>
  </div>`
  
})

Vue.component('data-form-text', 
{
  props: ['data'],
  computed: {
      dataJson: function(){
          return JSON.stringify(this.data);
      }
  },
  template: `<div class="form-group">
        <label>{{data.label}}</label>
        <input type="text" class="form-control" v-on:input="$emit('updated', $event.target.value)"/>
    </div>`  
})

Vue.component('data-form-choice', 
{
  props: ['data'],
  computed: {
      dataJson: function(){
          return JSON.stringify(this.data);
      }
  },
  template: `<div class="form-group">
        <label>{{data.label}}</label>
        <b-select :options="data.options">
        </b-select>
    </div>`  
})

Vue.component('data-form-optiongroup',
{
    props: ['data'],    
    template: `<div class="form-group">
        <label>{{data.label}}</label>
        <div v-for="option in data.options">
            <input :id="data.data-id" type="radio" :value="option"/> {{option}}
        </div>
    </div>`
})

Vue.component('data-form-range', 
{
  props: ['data'],
  computed: {
      dataJson: function(){
          return JSON.stringify(this.data);
      }
  },
  template: `<div class="form-group">
        <label>{{data.label}}</label>
        <div>Min: {{data.min}}</div>
        <div>Max: {{data.max}}</div>
    </div>`  
})

