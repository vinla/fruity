var deckServiceFactory = {
    methods : {
        deckService : function($http) {
            return {
                $http: $http,
                createDeck: function(name) {
                    return this.$http.post('/Index?handler=Create', {name: name});
                }
            }
        }
    }
};