var dataServiceFactory = {
    methods : {
        dataService : function($http) {
            return {
                $http: $http,
                loadForm: function() {
                    return this.$http.get('/Index?handler=Form');
                }
            }
        }
    }
};