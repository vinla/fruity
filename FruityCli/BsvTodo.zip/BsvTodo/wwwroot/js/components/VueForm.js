Vue.component('data-form', 
{
  props: ['elements'],
  data : function ()  {
    return {
      model: {}
    }
  },
  methods: {
    componentFor : function(type){
      return "data-form-"+type;
    },
    updateModel: function(dataElement, value) {        
        this.model[dataElement] = value;        
    }
  },
  template: `<div class="form">
    <div class="form-group" v-for="element in elements">
        <component v-bind:is="componentFor(element.type)" v-bind:data="element" v-on:updated="updateModel(element['data-id'], $event)"></component>
    </div>
  </div>`
  
})

Vue.component('data-form-text', 
{
  props: ['data'],
  computed: {
      dataJson: function(){
          return JSON.stringify(this.data);
      }
  },
  template: `<div class="form-group">
        <label>{{data.label}}</label>
        <input type="text" class="form-control" v-on:input="$emit('updated', $event.target.value)"/>
    </div>`  
})

Vue.component('data-form-choice', 
{
  props: ['data'],
  computed: {
      dataJson: function(){
          return JSON.stringify(this.data);
      }
  },
  template: `<div class="form-group">
        <label>{{data.label}}</label>
        <b-select :options="data.options">
        </b-select>
    </div>`  
})

Vue.component('data-form-optiongroup',
{
    props: ['data'],    
    template: `<div class="form-group">
        <label>{{data.label}}</label>
        <div v-for="option in data.options">
            <input :id="data.data-id" type="radio" :value="option"/> {{option}}
        </div>
    </div>`
})

Vue.component('data-form-range', 
{
  props: ['data'],
  computed: {
      dataJson: function(){
          return JSON.stringify(this.data);
      }
  },
  template: `<div class="form-group">
        <label>{{data.label}}</label>
        <div>Min: {{data.min}}</div>
        <div>Max: {{data.max}}</div>
    </div>`  
})

