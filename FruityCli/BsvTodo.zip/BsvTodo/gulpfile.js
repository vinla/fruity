var gulp = require('gulp');
var concat = require('gulp-concat');
var rename = require('gulp-rename');
var uglify = require('gulp-uglify');

var componentsSource = 'wwwroot/js/components/*.js';
var servicesSource = 'wwwroot/js/services/*.js';
var outputFolder = 'wwwroot/js'

gulp.task('components', function(){
    return gulp.src(componentsSource)
        .pipe(concat('components.js'))
        .pipe(gulp.dest(outputFolder))        
})

gulp.task('services', function(){
    return gulp.src(servicesSource)
        .pipe(concat('services.js'))
        .pipe(gulp.dest(outputFolder))        
})


gulp.task('default', ['components', 'services']);