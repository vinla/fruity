﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace BsvTodo.Pages
{
    [IgnoreAntiforgeryToken(Order=1001)]
    public class IndexModel : PageModel
    {
        public void OnGet()
        {

        }

        public IActionResult OnGetData()
        {
            var data = new [] 
            {
                new {value = "d", text = "Delta"},
                new {value = "e", text = "Echo"},
                new {value = "f", text = "Foxtrot"}
            };

            return new JsonResult(data);
        }

        public IActionResult OnPostCreate([FromBody]CreateData createData)
        {
            return new JsonResult(createData.name);
        }

        public class CreateData
        {
            public string name {get;set;}
        }
    }
}
