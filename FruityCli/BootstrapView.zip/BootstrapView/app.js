var app = new Vue({    
    el: '#app',
    data: {
        name: '',
        selected: null,
        options: [{value: "v", text: "Vincent"}, {value: 'k', text: "Kim"}]
    },
    methods:{
        updateName: function(name){
            this.name = name;
        }
    }
})