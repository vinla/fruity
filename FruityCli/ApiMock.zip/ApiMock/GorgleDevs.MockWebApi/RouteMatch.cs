using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace GorgleDevs.MockWebApi
{
    public class RouteMatch
	{
		private RouteSetup _routeSetup;
		private readonly bool _success;
		private readonly Dictionary<string, string> _wildcards;		

		private RouteMatch(bool success)
		{
			_success = success;
		}

		public RouteMatch(RouteSetup routeSetup, Dictionary<string, string> wildcards)
		{
			_success = true;
			_wildcards = wildcards;
			_routeSetup = routeSetup;
		}

		public static RouteMatch NoMatch => new RouteMatch(false);

		public bool Success => _success;

		public RouteSetup Setup => _routeSetup;

		public string GetResponse(string request)
		{
			var response = _routeSetup.Response;

			var placeholders = Regex.Matches(response, "{([A-Za-z]+)}");

			foreach(Match placeholder in placeholders)
			{
				var key = placeholder.Groups[1].Value;
				if(_wildcards.ContainsKey(key))
				{
					response = response.Replace(placeholder.Value, _wildcards[key]);
				}
			}

			return response;
		}
	}
}