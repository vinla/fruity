﻿using System;
using System.Linq;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace GorgleDevs.MockWebApi
{
    public class Startup
    {
		// This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.Run(async (context) =>
            {
				var path = context.Request.Path;
				var response = String.Empty;
				var bodyAsText = String.Empty;

				if(context.Request.ContentLength.GetValueOrDefault() > 0)
				{
					var buffer = new byte[(int)context.Request.ContentLength];
					await context.Request.Body.ReadAsync(buffer, 0, buffer.Length);
					bodyAsText = ASCIIEncoding.ASCII.GetString(buffer);										
				}				

				if (path.StartsWithSegments("/_setup"))
				{				
					var route = path.Value.Replace("/_setup", "");

					DataCache.RouteSetups.RemoveAll(r => r.Route == route);
					DataCache.RouteSetups.Add(new RouteSetup(route, bodyAsText));

					response = path;					
				}
				else if(path.StartsWithSegments("/_validate"))
				{
					var route = path.Value.Replace("/_validate", "");
					var routeSetup = DataCache.RouteSetups.SingleOrDefault(r => r.Route == route);

					if(routeSetup != null)
					{
						var responseObject = new 
						{
							count = routeSetup.Requests.Count(),
							requests = routeSetup.Requests.Select(rq => new 
							{
								path = rq.path,
								body = rq.request
							})
						};

						response = Newtonsoft.Json.JsonConvert.SerializeObject(responseObject);
					}
				}
				else
				{
					var routeMatch = DataCache.RouteSetups.Select(r => r.MatchesOn(path))
							.Where(rm => rm.Success).FirstOrDefault();

					if(routeMatch != null)
					{
						response = routeMatch.GetResponse(bodyAsText);
						routeMatch.Setup.LogRequest(path, bodyAsText);
					}										
				}

				await context.Response.WriteAsync(response);
			});
        }
    }

	
}
