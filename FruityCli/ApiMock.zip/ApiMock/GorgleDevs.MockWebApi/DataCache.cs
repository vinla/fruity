using System.Collections.Generic;

namespace GorgleDevs.MockWebApi
{
    public class DataCache
	{
		private static List<RouteSetup> _routeSetups = new List<RouteSetup>();

		public static List<RouteSetup> RouteSetups => _routeSetups;
	}	
}