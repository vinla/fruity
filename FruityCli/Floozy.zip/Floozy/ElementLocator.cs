using System;
using OpenQA.Selenium;

namespace Floozy
{
    public delegate IWebElement ElementLocator(IWebDriver webDriver);
}