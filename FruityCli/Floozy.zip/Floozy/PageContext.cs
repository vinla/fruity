using System;
using System.Linq.Expressions;
using OpenQA.Selenium;

namespace Floozy
{
    public class PageContext<TPageModel> where TPageModel : class, new()
    {
        private readonly IWebDriver _webDriver;
        private readonly TPageModel _pageModel;

        public PageContext(IWebDriver webDriver, TPageModel pageModel)
        {
            _webDriver = webDriver ?? throw new ArgumentNullException(nameof(webDriver));
            _pageModel = pageModel ?? throw new ArgumentNullException(nameof(pageModel));
        }        

        public InputContext<TPageModel> Type(string keysToType)
        {
            return new InputContext<TPageModel>(this, keysToType);
        }

        public ExpectationContext<TPageModel> Click<TProperty>(Expression<Func<TPageModel, TProperty>> property) 
        {            
            throw new NotImplementedException();
        }
    }
}