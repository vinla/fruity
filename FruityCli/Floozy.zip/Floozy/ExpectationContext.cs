namespace Floozy
{
    public class ExpectationContext<TPageModel> where TPageModel : class, new()
    {

    }
}