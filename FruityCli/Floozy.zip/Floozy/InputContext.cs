using System;
using System.Linq.Expressions;
using OpenQA.Selenium;

namespace Floozy
{
     public class InputContext<TPageModel> where TPageModel : class, new()
    {
        private readonly PageContext<TPageModel> _page;
        public InputContext(PageContext<TPageModel> page, string text)
        {
            _page = page ?? throw new ArgumentNullException(nameof(page));
        }

        public PageContext<TPageModel> Into<TProperty>(Expression<Func<TPageModel, TProperty>> property)
        {
            return _page;
        }
    }
}